#include <stdio.h>
#include <8queen.h>

int main(void) {
	alg::Queen8 q;
	q.solve();
}

