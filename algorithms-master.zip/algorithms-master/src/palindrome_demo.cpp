#include "palindrome.h"
#include <stdio.h>

int main() {
	alg::palindrome("banana");
	alg::palindrome("abba");
	alg::palindrome("aaaaa");
}
